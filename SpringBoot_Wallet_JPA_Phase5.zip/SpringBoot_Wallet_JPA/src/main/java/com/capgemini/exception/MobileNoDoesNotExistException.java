package com.capgemini.exception;

public class MobileNoDoesNotExistException extends Exception {

}
