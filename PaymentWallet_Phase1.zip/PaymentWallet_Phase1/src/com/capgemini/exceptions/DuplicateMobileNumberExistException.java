package com.capgemini.exceptions;

public class DuplicateMobileNumberExistException extends Exception {

}
